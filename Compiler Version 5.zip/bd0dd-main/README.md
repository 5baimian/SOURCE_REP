# ARM Compiler Version5 独立安装包

## 简介
本仓库提供了一个资源文件，用于独立安装ARM Compiler Version5，适用于Keil MDK5.37版本。由于Keil MDK5.37版本不再预装ARM Compiler Version5，因此需要用户自行安装ARMCC（缺少的编译器）。

## 资源文件说明
- **文件名称**: ARM Compiler Version5 独立安装包
- **适用版本**: Keil MDK5.37
- **功能**: 提供ARMCC编译器的独立安装包，解决Keil MDK5.37版本缺少ARM Compiler Version5的问题。

## 安装步骤
1. 下载本仓库提供的资源文件。
2. 解压下载的文件。
3. 按照解压后的安装说明进行ARM Compiler Version5的安装。
4. 安装完成后，重新启动Keil MDK5.37，确保ARMCC编译器已成功集成。

## 注意事项
- 请确保您的Keil MDK5.37版本与本资源文件兼容。
- 安装过程中请遵循安装说明，避免出现错误。

## 支持与反馈
如果您在安装过程中遇到任何问题，或有任何建议，请通过仓库的Issues页面提交反馈。我们将尽快为您提供帮助。

感谢您的使用！